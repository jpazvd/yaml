NOTE:  readme.txt for Stata Journal submission
------------------------------------------------------------------------------

Package name:   <leave blank>

DOI:  <leave blank>

Title:  Reading and writing YAML files in Stata

Author 1 name:  João Pedro Azevedo
Author 1 from:  UNICEF, Data and Analytics, New York, USA
Author 1 email: jazevedo@unicef.org

Author 2 name:  
Author 2 from:  
Author 2 email: 

Author 3 name:  
Author 3 from:  
Author 3 email: 

Author 4 name:  
Author 4 from:  
Author 4 email: 

Author 5 name:  
Author 5 from:  
Author 5 email: 

Help keywords:  yaml

File list: yaml.ado yaml.sthlp yaml_sj_article_examples.do yaml_sj_article_examples.log unicef_indicators.yaml unicef_dataflows.yaml config.yaml indicators.yaml

Notes: The yaml command requires Stata 17 or later for frames support.
       Example YAML files simulate UNICEF SDMX API metadata structure.
       All examples can be reproduced using yaml_sj_article_examples.do.
